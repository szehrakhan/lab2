/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coinchange;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author szehra.bscs13seecs
 */
public class CoinChangeTest {
    
    public CoinChangeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of greedy method, of class CoinChange.
     */
    @Test
    public void testGreedy() {
        System.out.println("greedy");
        int money = 0;
        CoinChange instance = new CoinChange();
        int expResult = 0;
        int result = instance.greedy(money);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of dynamic method, of class CoinChange.
     */
    @Test
    public void testDynamic() {
        System.out.println("dynamic");
        int money = 0;
        CoinChange instance = new CoinChange();
        int expResult = 0;
        int result = instance.dynamic(money);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       // fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class CoinChange.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        CoinChange.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}

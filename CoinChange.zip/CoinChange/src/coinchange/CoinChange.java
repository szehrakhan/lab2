/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coinchange;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author szehra.bscs13seecs
 */
public class CoinChange {
    
    
    
    

    /**
     * @param args the command line arguments
     * 
     */
    
    int denominations[]={1,5,10,25};

    int greedy(int money){
    
  int residual=money;
  
  List coins = new ArrayList();
  int max=0;
//residual=money;
  
  while(residual!=0){
      max=denominations[0];
  for(int i=3;i>=0;i--)

  {
 if(denominations[i]<=residual)
 {
     coins.add(denominations[i]);
     
 residual=residual-denominations[i];
 break;
 }    
      }
  }
  //for(int i=0;i<coins.size();i++)
      System.out.println(coins);
  
  return coins.size();
    
    }
    
   int dynamic(int money){
   int[] coins=new int[money];
   coins[0]=0;
   for(int i=1;i<money;i++)
   {
   coins[i]=100000000;
   for(int j=0;j<4;j++){
   if(i>=denominations[j]&&(1+coins[ i-denominations[j] ]<coins[i]))
   {
       coins[i]=1+(coins[i-denominations[j]]);
       //System.out.println(coins[i]);
   }   
   
   }
   
   
   }
   System.out.println("valuie: "+coins[money-1]);
   return coins[money-1];
   
   
   
//coin(0)=0;
   
       
       
   
   } 
    
    
    
    
    public static void main(String[] args) {
        // TODO code application logic here
   CoinChange myalgo=new CoinChange();
    System.out.println("enter ammount");
    Scanner in= new Scanner(System.in);
    int amount=in.nextInt();
    System.out.println("total coins fr greaady="+myalgo.greedy(amount));
    int k=myalgo.dynamic(amount);
    
    }
    
    
}

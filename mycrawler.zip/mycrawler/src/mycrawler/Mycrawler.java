/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mycrawler;
import java.io.File;
import java.util.HashMap;
import java.util.Set;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
/**
 *
 * @author Saman
 */
public class Mycrawler {

    
      HashMap<String, File> myindex = new HashMap<String, File>();
    
    
    
   void makeIndex(String name)
   {
       
       File folder = new File(name);
   File[] list_files;
       list_files = folder.listFiles();
   
for (int i = 0; i < list_files.length; i++) {
      if (list_files[i].isFile()) {
          myindex.put(list_files[i].getName(),folder);
        //System.out.println("File " + list_files[i].getName());
      } else if (list_files[i].isDirectory()) {
        String next=folder+ "\\"+ list_files[i].getName();
        System.out.println(next);
       //if((list_files[i].getName()!="$RECYCLE.BIN")||(i!=(list_files.length-1))|| list_files[i].getName()!="System Volume Information")
        
        if(i!=(list_files.length-1))
        makeIndex(next);

//System.out.println("Directory " + list_files[i].getName());
      }
    }

//System.out.println(list_files);
   
   }
    
   
   void print(){
   
   
       for (String name: myindex.keySet()){

            String key =name.toString();
            String value = myindex.get(name).toString();  
            System.out.println(key + " " + value);  


} 
       
       
      
       
       
       
   /*for (Hashmap.Entry<String, Integer> entry : map.entrySet()) {
    String key = entry.getKey().toString();
    Integer value = entry.getValue();
    System.out.println("key, " + key + " value " + value);*/
}
   
   
    void search(String file_name)
       {
    
           /*Set<String> set = myindex.keySet()
                     .stream()
                     .filter(s -> s.startsWith("address"))
                     .collect(Collectors.toSet());*/
           
           
           
           if (myindex.containsKey(file_name)) {
               System.out.println("file is present at :" +myindex.get(file_name) );
           }
else
               System.out.println("does not exist");
       
       }
   
   
    
     private static List<String> searchDefinition(final HashMap<String, File> stockSymbolMap,
                                                final String regex ) throws IOException {
  
                                final List<String> results = new ArrayList<String>();
  
                                final Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
  
                                final Set<String> keys = stockSymbolMap.keySet();
  
                                final Iterator<String> ite = keys.iterator();
                                
                                while (ite.hasNext()) {
                                                String candidate = ite.next();
                                                System.out.println("candidate = " + candidate );
                                                Matcher matcher = pattern.matcher(candidate);
  
                                                if (matcher.matches()) {
                                                                
                                                                results.add(candidate);
                                                                System.out.println("Match found for : " + candidate );
                                                }
                                }
                                
                                return results;
  
                }
    
    
    
   

    
    
    /**
     * 
     * 
     * 
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        //Scanner in=new Scanner();
        
        Mycrawler myindex=new Mycrawler();
        //myindex.makeIndex("C:\\");
        myindex.makeIndex("D:\\");
        myindex.print();
        myindex.search("LAB5.docx");
        try {
        List list = searchDefinition(myindex.myindex, "bachpan" );
                                                
                                                System.out.println(list);
        }catch(Exception e){
                                                e.printStackTrace();
                                }
        // TODO code application logic here
    }
    
}

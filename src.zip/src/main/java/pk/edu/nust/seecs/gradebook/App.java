package pk.edu.nust.seecs.gradebook;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import pk.edu.nust.seecs.gradebook.dao.CloDao;
import pk.edu.nust.seecs.gradebook.entity.Clo;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.commons.codec.digest;
/**
 * My main App. 
 * <p>
 This executes everything.
 */

public class App {
    
    
    /*public class files{
    
    String file;
    String hash;
    
    public String getFile()
    {
     return file;
    
    }
    
     public String getHash()
    {
     return hash;
    
    }
    
    
     public void setFile(String name)
    {
     this.file=name;
    
    }
     
     
      public void setHash(String h)
    {
     this.hash=h;
    
    }
     
     
    }*/
    

    public static void main(String[] args) {
        CloDao clodao = new CloDao();
String name="myfile.txt";
        try {
		FileInputStream fis = new FileInputStream(name);
String md5 = org.apache.commons.codec.digest.DigestUtils.md5Hex(fis);
fis.close();	
			
         Clo clo = new Clo();
        clo.setName(name);
        clo.setHash(md5);
        }

		catch (IOException e) {
			e.printStackTrace();
		}
        
        
     //checking for integrity
        
        
        Configuration cfg=new Configuration();  
		cfg.configure("hibernate.cfg.xml");//populates the data of the configuration file  
		//creating seession factory object  
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(cfg.getProperties()). build();
		SessionFactory factory=cfg.buildSessionFactory(serviceRegistry);
		//creating session object  
		Session session=factory.openSession();  
			//creating transaction object  
			Transaction t=session.beginTransaction();  
			
			session.persist(clo);//persisting the object  
			t.commit();//transaction is commited  
		session.close();  
        





        
        
        
        
        
        
        
        
        
        // Add new clo
       
        
        clodao.addClo(clo);

        clodao.updateClo(clo);

        for (Clo iter : clodao.getAllClos()) {
            System.out.println(iter);
        }

        // Get clo by id
        System.out.println(clodao.getCloById(1));

        
    }

}